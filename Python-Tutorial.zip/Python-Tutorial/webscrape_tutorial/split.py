text = "Why does Jack Make me do this thingzz?? Hey gus!"

cost = "The cost to buy apples is $69.99 sadl;fjdasfljk $70"

price = cost.split("$")
# print(price)

# print(type(price[1]))


x = 123
print(type(x))
print("------------")
string_x = str(x)

print(string_x)
print(type(string_x))