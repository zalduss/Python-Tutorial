
name = input("What is your name: ")
age = input("What is your age: ")

# Condition Here 👇
