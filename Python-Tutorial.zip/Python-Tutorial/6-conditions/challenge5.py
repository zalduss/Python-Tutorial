
# 👇 Ask the user for two numbers and store it in the variables num1 and num2
# input here


# Condition Here 👇


print("4" == 4)
x = 5
x is 5
x equals to 5