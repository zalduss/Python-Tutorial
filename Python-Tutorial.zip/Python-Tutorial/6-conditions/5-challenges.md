
# Challenges

### Challenge 1

- Given a person's name and age, write a python script that checks the age of the person, then print one of the two messages: 
    - `"Go home, {insert_name_here}!"`, if they are younger than 21. 
    - `"Welcome, {insert_name_here}!"`, if they are 21 or older. 
    
Write your solution inside [challenge1.py](./challenge1.py)


---
### Challenge 2

- Given a number, check if the number is greater than 10 or eqaul to 7, then print True or False. 
    
Write your solution inside [challenge2.py](./challenge2.py)


---
### Challenge 3


- Given a number, check if the number is less than 30 and greater than 20, then print True or False. 

    
Write your solution inside [challenge3.py](./challenge3.py)


---

### Challenge 4

- Given a number, check if the number is not equal to 10, then print True or False. 
    
Write your solution inside [challenge4.py](./challenge4.py)


---

### Challenge 5

- 
- Given 2 numbers, check if num2 is less than num1 or if num1 and num2 are equal, then print True or False.
- Check 
    
Write your solution inside [challenge5.py](./challenge5.py)
