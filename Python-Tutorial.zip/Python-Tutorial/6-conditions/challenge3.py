
# 👇 Ask the user for a number and store it in the variable name: number 
# input here


# Condition Here 👇

