
- How to install python (Windows, mac)
- How to check if python is installed
- How to download visual studio code
- How to open visual studio code
- Extensions to download
- How to create and run first program
    - the extension needed on the end of the file to tell the machine it is a python file (.py)
    - what buttons to click 
    - What to type (hello world program)
    - How to run (different methods to run file)
    - if the file is in a directory or outside
    - how to navigate the directory
    - using the integrated terminal


1. Open IDE in this example we are going to be using Visual Studio Code