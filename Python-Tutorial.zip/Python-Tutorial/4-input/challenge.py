# Asks the user for their dog's name and age.
# Calculates the dog's age in human years (1 dog year = 7 human years).
# Prints a message stating the dog's name and age in human years.

