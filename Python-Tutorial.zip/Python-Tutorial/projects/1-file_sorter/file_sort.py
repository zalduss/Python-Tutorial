import os
import shutil

# Define the directory to organize
directory = '[Your Directory Path Here]'

# Define the file type categories and their corresponding extensions
file_types = {
    'Documents': ['.pdf', '.doc', '.docx', '.txt'],
    # Add other categories here as needed
}

# Add the remaining part of the provided script here