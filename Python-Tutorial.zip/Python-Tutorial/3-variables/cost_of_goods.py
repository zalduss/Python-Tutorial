# Create a variable named item_price and assign it a float value.
# Create a variable named quantity and assign it an integer.
# Calculate the total cost and store it in a variable named total_cost.
# Print a message to the console that shows the item price, quantity, and total cost in a readable format.

# Write the code below 👇


