# Modify the following list using list methods we've discussed to achieve the expected result:

my_list = [1, 2, 3, 4, 5]

# Expected Result
# [6, 5, 4, 3, 2, 1, 0]

# Write your code below this line 👇
