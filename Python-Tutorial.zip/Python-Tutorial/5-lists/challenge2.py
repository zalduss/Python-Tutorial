# Merge `list1` and `list2` into a new list called `list3` with the following elements:

list1 = [1, 2, 3, 4, 5]
list2 = [5, 6, 7, 8, 9, 10]

# Note that both `list1` and `list2` include the number 5. You will need to find a way to eliminate the duplicate.

# Write your code below this line 👇





# Expected Result
print(list3)
# [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
