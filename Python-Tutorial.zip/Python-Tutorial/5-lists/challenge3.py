# Modify the following list to achieve the expected result:
list1 = [1, 3, 5, 7, 9]

# Write your code below this line 👇




print(list1)
# Expected Result
# [10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
