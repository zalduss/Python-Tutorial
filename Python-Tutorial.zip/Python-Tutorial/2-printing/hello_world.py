# This is a simple Python program that prints "Hello, World!" to the terminal.

# The 'print' function is used to output data to the standard output device (screen).
print("Hello, World!")  # Printing "Hello, World!" to the terminal

# When this program is run, it will display "Hello, World!" in the terminal screen.
