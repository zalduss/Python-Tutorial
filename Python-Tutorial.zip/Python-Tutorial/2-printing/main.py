# Print all three of the following lines to the terminal:

# Day 1 - Python Print Function
# The function is declared like this:
# print('what to print')

# Write the code below 👇


