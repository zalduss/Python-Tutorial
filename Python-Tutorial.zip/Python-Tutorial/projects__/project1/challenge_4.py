
# Challenge 4: Filter by Zipcodes

# Import necessary libraries
import pandas as pd

# Load the dataset
file_path = 'us-500.csv'
data = pd.read_csv(file_path)

zipcodes = [21224, 8812, 99708, 90006, 10009]

# TODO: Write code to filter customers based on a list of zipcodes and save the result to a new CSV file

