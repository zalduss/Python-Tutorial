
# Challenge 2: Filter Customers in NY

# Import necessary libraries
import pandas as pd

# Load the dataset
file_path = 'us-500.csv'
data = pd.read_csv(file_path)

# TODO: Write code to filter out customers in NY state and save them to a new CSV file called 'ny_leads'
