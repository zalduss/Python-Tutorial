
# Challenge 3: Extract Specific Fields

# Import necessary libraries
import pandas as pd

# Load the dataset
file_path = 'us-500.csv'
data = pd.read_csv(file_path)

# TODO: Write code to extract first name, last name, email, and both phone numbers, then save to a new CSV file
