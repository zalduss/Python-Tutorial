
# Challenge 1: Sort Data by State

# Import necessary libraries
import pandas as pd

# Load the dataset
file_path = 'us-500.csv'
data = pd.read_csv(file_path)


# TODO: Write code to sort the data by state and save it to a new CSV file 'sorted-us-500'
