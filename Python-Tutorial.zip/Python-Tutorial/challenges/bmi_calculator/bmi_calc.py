import math

# Example Input 1
# 1.75
# 80

# Expected Output 1
# 26

# ----------------------------------
# Example Input 2
# 1.58
# 57

# Expected Output 1
# 22

# 1st input: enter height in meters e.g: 1.75
height = input()
# 2nd input: enter weight in kilograms e.g: 80
weight = input()
# 🚨 Don't change the code above 👆

# Write your code below this line 👇


