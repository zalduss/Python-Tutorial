import os

path, filename = os.path.split('projects__/project1/challenge_1.py')


print(path)
print(filename)